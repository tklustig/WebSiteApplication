Damit die Applikation sofort nuzbar ist, wurden Ihr Vokabellisten beigef�gt. 
Erstellen sie �ber den Explorer in Ihrem Ordner 'Dokumente' einen Ordner 'Vokabelprogramm'. Alternativ 
k�nnen Sie den Ordner auch �ber die Applikation erzeugen lassen, indem Sie sie starten und wieder 
beenden.Entpacken Sie sodann die beigef�gten Listen der Datei 'Listen.zip' in den soeben erstellten 
Ordner.Ab jetzt stehen Ihnen drei Demolisten zum Test zur Verf�gung. Selbstverst�ndlich k�nnen sie diese
Listen ab�ndern oder aber neue erstellen. Demn�chst werden noch mehr Listen in folgenden Sprachen
auf meinem Server gehostet: Englisch, Franz�sisch, Spanisch, Russisch. Besuchen Sie meine WebSite unter:
http://tklustig.ddns.net

Bei Problemen kontaktieren Sie mich �ber die MessageBox der WebSite